import React, { useEffect, useState } from "react";
import { ethers } from "ethers";
import { abi } from "./marketplace";

const contractAddress = "YOUR_CONTRACT_ADDRESS";

function App() {
  const [nfts, setNfts] = useState([]);
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");

  const loadNFTs = async () => {
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const contract = new ethers.Contract(contractAddress, abi, provider);
    const count = await contract.nftCount();
    const items = [];
    for (let i = 1; i <= count; i++) {
      const item = await contract.nfts(i);
      items.push(item);
    }
    setNfts(items);
  };

  const createNFT = async () => {
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const contract = new ethers.Contract(contractAddress, abi, signer);
    const tx = await contract.createNFT(name, ethers.utils.parseEther(price));
    await tx.wait();
    loadNFTs();
  };

  return (
    <div>
      <h1>NFT Marketplace</h1>
      <input placeholder="NFT Name" onChange={e => setName(e.target.value)} />
      <input placeholder="Price in ETH" onChange={e => setPrice(e.target.value)} />
      <button onClick={createNFT}>Create NFT</button>
      <div>
        {nfts.map((nft, i) => (
          <div key={i}>
            <p>{nft.name}</p>
            <p>Price: {ethers.utils.formatEther(nft.price)} ETH</p>
            <p>Owner: {nft.owner}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default App;
