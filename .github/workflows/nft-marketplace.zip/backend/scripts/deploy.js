async function main() {
    const [deployer] = await ethers.getSigners();
    console.log("Deploying contract with the account:", deployer.address);
    const Marketplace = await ethers.getContractFactory("NFTMarketplace");
    const marketplace = await Marketplace.deploy();
    console.log("NFTMarketplace deployed to:", marketplace.address);
}
main().catch((error) => {
    console.error(error);
    process.exitCode = 1;
});
